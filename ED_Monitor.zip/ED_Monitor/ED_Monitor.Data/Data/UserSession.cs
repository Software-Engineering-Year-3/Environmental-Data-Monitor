namespace ED_Monitor.Data
{
    public static class UserSession
    {
        public static string Name { get; set; } = string.Empty;
        public static string Email { get; set; } = string.Empty;
        public static string Role { get; set; } = string.Empty;
    }
}
