using Microsoft.Maui.Controls;
using ED_Monitor.Data;
using ED_Monitor.Pages;

namespace ED_Monitor.Pages;

public partial class ReportPage : ContentPage
{
	public ReportPage()
	{
		InitializeComponent();
	}
}